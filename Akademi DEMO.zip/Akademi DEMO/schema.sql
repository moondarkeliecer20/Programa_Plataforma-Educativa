-- ============================================================
-- AKADEMI · Esquema de base de datos para el sistema de login
-- Motor: PostgreSQL (Supabase)
-- Ejecutar en: Supabase Dashboard → SQL Editor
-- ============================================================

-- Supabase ya trae la tabla auth.users (gestiona email, password
-- hasheado, proveedores OAuth como google/facebook/apple, etc).
-- Aquí creamos una tabla "profiles" para los datos propios de la
-- app, ligada 1:1 a auth.users.

-- 1) TABLA DE PERFILES ------------------------------------------------
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  avatar_url text,
  provider text default 'email',        -- email | google | facebook | apple
  role text not null default 'estudiante', -- estudiante | admin
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- 2) LOG DE SEGURIDAD (auditoría de inicios de sesión) ----------------
create table if not exists public.security_audit_log (
  id bigint generated always as identity primary key,
  user_id uuid references auth.users(id) on delete set null,
  event_type text not null,        -- login_success | login_failed | logout | password_reset
  provider text,                   -- email | google | facebook | apple
  ip_address text,
  user_agent text,
  created_at timestamptz not null default now()
);

-- 3) CONTROL DE INTENTOS FALLIDOS (para bloqueo de cuenta) ------------
create table if not exists public.login_attempts (
  id bigint generated always as identity primary key,
  email text not null,
  success boolean not null,
  attempted_at timestamptz not null default now()
);

create index if not exists idx_login_attempts_email_time
  on public.login_attempts (email, attempted_at desc);

-- ============================================================
-- TRIGGER: crear perfil automáticamente al registrarse
-- ============================================================
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer set search_path = public
as $$
begin
  insert into public.profiles (id, full_name, avatar_url, provider)
  values (
    new.id,
    coalesce(new.raw_user_meta_data->>'full_name', new.raw_user_meta_data->>'name'),
    new.raw_user_meta_data->>'avatar_url',
    coalesce(new.raw_app_meta_data->>'provider', 'email')
  );
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- ============================================================
-- ROW LEVEL SECURITY (RLS) — regla clave del sistema de seguridad
-- ============================================================
alter table public.profiles enable row level security;
alter table public.security_audit_log enable row level security;
alter table public.login_attempts enable row level security;

-- Un usuario solo puede ver y editar SU PROPIO perfil
create policy "profiles: leer el propio perfil"
  on public.profiles for select
  using (auth.uid() = id);

create policy "profiles: actualizar el propio perfil"
  on public.profiles for update
  using (auth.uid() = id);

-- Los admins pueden ver todos los perfiles (útil para tu panel de contest)
create policy "profiles: admins ven todo"
  on public.profiles for select
  using (
    exists (
      select 1 from public.profiles p
      where p.id = auth.uid() and p.role = 'admin'
    )
  );

-- El log de auditoría: cada usuario ve solo sus propios eventos
create policy "audit: leer los propios eventos"
  on public.security_audit_log for select
  using (auth.uid() = user_id);

-- Solo el backend (service_role, usado en Edge Functions) puede insertar
-- en audit log y login_attempts. El cliente (frontend) nunca escribe aquí
-- directamente, así se evita que alguien falsifique su propio historial.
-- (No se crea policy de insert para "authenticated" ni "anon": por defecto
-- RLS bloquea todo lo que no tenga policy explícita.)
