// LoginView-actualizado.jsx
// Reemplazo del componente LoginView original (plataforma-educativa.jsx, línea ~560)
// ahora conectado al sistema de autenticación real vía useAuth().
//
// Para integrarlo:
// 1) Envuelve tu <App /> con <AuthProvider> (ver App.jsx / main.jsx de ejemplo).
// 2) Sustituye la función LoginView en plataforma-educativa.jsx por esta versión.
// 3) Importa `useAuth` desde "./AuthContext".

import { useState } from "react";
import { useAuth } from "./AuthContext";

function LoginView({ onBack, onSuccess }) {
  const { signIn, signUp, signInWithOAuth } = useAuth();
  const [mode, setMode] = useState("login"); // login | registro
  const [fullName, setFullName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [busy, setBusy] = useState(false);

  async function handleSubmit(e) {
    e.preventDefault();
    setError("");
    setNotice("");
    setBusy(true);
    try {
      if (mode === "login") {
        await signIn({ email, password });
        onSuccess?.();
      } else {
        await signUp({ email, password, fullName });
        setNotice("Cuenta creada. Revisa tu correo para confirmar tu cuenta.");
      }
    } catch (err) {
      setError(traducirError(err.message));
    } finally {
      setBusy(false);
    }
  }

  async function handleOAuth(provider) {
    setError("");
    try {
      await signInWithOAuth(provider);
      // El navegador redirige al proveedor; onSuccess se dispara al volver,
      // vía el listener de onAuthStateChange en AuthContext.
    } catch (err) {
      setError(traducirError(err.message));
    }
  }

  return (
    <div style={S.panelCenter}>
      <div style={S.badge}>{mode === "login" ? "iniciar sesión" : "crear cuenta"}</div>
      <h1 style={S.h1}>{mode === "login" ? "Bienvenido de nuevo" : "Crea tu cuenta"}</h1>
      <p style={S.p}>
        {mode === "login"
          ? "Ingresa tus datos para acceder a Akademi."
          : "Regístrate para guardar tu progreso en Akademi."}
      </p>

      {/* Botones de proveedores externos */}
      <div style={{ display: "flex", flexDirection: "column", gap: 8, width: "100%", marginBottom: 14 }}>
        <button type="button" style={S.oauthBtn} onClick={() => handleOAuth("google")} disabled={busy}>
          Continuar con Google
        </button>
        <button type="button" style={S.oauthBtn} onClick={() => handleOAuth("facebook")} disabled={busy}>
          Continuar con Facebook
        </button>
        <button type="button" style={S.oauthBtn} onClick={() => handleOAuth("apple")} disabled={busy}>
          Continuar con Apple
        </button>
      </div>

      <div style={{ textAlign: "center", fontSize: 12, opacity: 0.6, margin: "4px 0 12px" }}>
        — o con tu correo —
      </div>

      <form style={S.loginForm} onSubmit={handleSubmit}>
        {mode === "registro" && (
          <input
            style={S.loginInput}
            type="text"
            placeholder="Nombre completo"
            value={fullName}
            onChange={(e) => setFullName(e.target.value)}
            required
          />
        )}
        <input
          style={S.loginInput}
          type="email"
          placeholder="Correo electrónico"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
        />
        <input
          style={S.loginInput}
          type="password"
          placeholder="Contraseña"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          minLength={6}
          required
        />
        <button style={S.cta} type="submit" disabled={busy}>
          {busy ? "Un momento…" : mode === "login" ? "Entrar" : "Registrarme"}
        </button>
      </form>

      {error && <div style={{ ...S.loginNoticeBox, color: "var(--bad, #c0392b)" }}>{error}</div>}
      {notice && <div style={S.loginNoticeBox}>{notice}</div>}

      <button
        style={S.linkBtn}
        onClick={() => {
          setMode(mode === "login" ? "registro" : "login");
          setError("");
          setNotice("");
        }}
      >
        {mode === "login" ? "¿No tienes cuenta? Regístrate" : "¿Ya tienes cuenta? Inicia sesión"}
      </button>
      <button style={S.linkBtn} onClick={onBack}>
        ← Volver al menú
      </button>
    </div>
  );
}

// Traduce los mensajes de error más comunes de Supabase al español
function traducirError(msg = "") {
  const m = msg.toLowerCase();
  if (m.includes("invalid login credentials")) return "Correo o contraseña incorrectos.";
  if (m.includes("user already registered")) return "Ya existe una cuenta con ese correo.";
  if (m.includes("email not confirmed")) return "Debes confirmar tu correo antes de entrar.";
  if (m.includes("password should be at least")) return "La contraseña debe tener al menos 6 caracteres.";
  return "Ocurrió un error. Intenta de nuevo en unos segundos.";
}

export default LoginView;

// Agregar este estilo nuevo al objeto S existente en plataforma-educativa.jsx:
//
// oauthBtn: {
//   width: "100%",
//   padding: "10px 14px",
//   borderRadius: 10,
//   border: "1px solid rgba(var(--ink-rgb),0.15)",
//   background: "rgba(var(--ink-rgb),0.03)",
//   fontFamily: "'Inter', sans-serif",
//   fontWeight: 600,
//   fontSize: 14,
//   cursor: "pointer",
// },
