// supabaseClient.js
// Cliente único de Supabase, reutilizado en toda la app.
// Requiere: npm install @supabase/supabase-js

import { createClient } from "@supabase/supabase-js";

// Estas dos variables NUNCA son secretas: la "anon key" está diseñada
// para usarse en el navegador. La seguridad real la da RLS (ver schema.sql)
// y NO estas claves. La "service_role key" (secreta) solo se usa del lado
// del servidor / Edge Functions, jamás en el frontend.
const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  console.error(
    "Faltan variables de entorno VITE_SUPABASE_URL / VITE_SUPABASE_ANON_KEY. Revisa tu archivo .env"
  );
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
    detectSessionInUrl: true, // necesario para el redirect de OAuth
  },
});
