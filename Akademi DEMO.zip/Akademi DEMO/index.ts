// supabase/functions/security-log/index.ts
//
// API de seguridad de Akademi (Supabase Edge Function, Deno).
// Se llama DESPUÉS de cada intento de login desde el frontend, para:
//   1) Registrar el intento (éxito o fallo) en login_attempts / security_audit_log.
//   2) Bloquear temporalmente una cuenta tras 5 fallos en 15 minutos.
//
// Deploy: supabase functions deploy security-log
// Requiere en el proyecto: SUPABASE_URL y SUPABASE_SERVICE_ROLE_KEY
// (se inyectan automáticamente como variables de entorno del Edge Function).

import { serve } from "https://deno.land/std@0.203.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const MAX_INTENTOS = 5;
const VENTANA_MINUTOS = 15;

const supabaseAdmin = createClient(
  Deno.env.get("SUPABASE_URL")!,
  Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")! // clave secreta: solo existe aquí, nunca en el frontend
);

serve(async (req) => {
  if (req.method !== "POST") {
    return new Response(JSON.stringify({ error: "Método no permitido" }), { status: 405 });
  }

  try {
    const { email, success, provider, user_id } = await req.json();
    if (!email || typeof success !== "boolean") {
      return new Response(JSON.stringify({ error: "Faltan parámetros: email, success" }), { status: 400 });
    }

    const ip = req.headers.get("x-forwarded-for") ?? "desconocida";
    const userAgent = req.headers.get("user-agent") ?? "desconocido";

    // 1) Registrar el intento
    await supabaseAdmin.from("login_attempts").insert({ email, success });

    await supabaseAdmin.from("security_audit_log").insert({
      user_id: user_id ?? null,
      event_type: success ? "login_success" : "login_failed",
      provider: provider ?? "email",
      ip_address: ip,
      user_agent: userAgent,
    });

    // 2) Revisar intentos fallidos recientes para ese correo
    const desde = new Date(Date.now() - VENTANA_MINUTOS * 60_000).toISOString();
    const { data: recientes, error } = await supabaseAdmin
      .from("login_attempts")
      .select("success")
      .eq("email", email)
      .gte("attempted_at", desde)
      .order("attempted_at", { ascending: false })
      .limit(MAX_INTENTOS);

    if (error) throw error;

    const fallosSeguidos = recientes.every((r) => r.success === false) && recientes.length >= MAX_INTENTOS;

    return new Response(
      JSON.stringify({
        ok: true,
        blocked: fallosSeguidos,
        message: fallosSeguidos
          ? `Cuenta bloqueada temporalmente por ${VENTANA_MINUTOS} minutos tras ${MAX_INTENTOS} intentos fallidos.`
          : "Registrado.",
      }),
      { headers: { "Content-Type": "application/json" } }
    );
  } catch (err) {
    return new Response(JSON.stringify({ error: String(err) }), { status: 500 });
  }
});
