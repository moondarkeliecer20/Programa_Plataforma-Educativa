
"""
Edu-AI Backend
-------------
Motor de IA educativa para conectar una aplicación React/JSX mediante HTTP.

Qué hace:
- Recibe texto o archivos PDF/PPTX.
- Extrae y analiza contenido.
- Detecta temas, subtemas y conceptos.
- Genera evaluaciones diagnósticas.
- Genera juegos de memoria y adivinanzas.
- Analiza respuestas de estudiantes.
- Calcula un nivel de dominio por tema.
- Recomienda refuerzo.
- Guarda usuarios, materiales, temas, preguntas y progreso en SQL.

Requisitos:
    pip install -r requirements.txt

Configuración:
    Crea un archivo .env:
        OPENAI_API_KEY=tu_clave
        DATABASE_URL=postgresql+psycopg://usuario:password@localhost:5432/edu_ai

Ejecutar:
    uvicorn edu_ai:app --reload --host 0.0.0.0 --port 8000

API:
    GET  /api/health
    POST /api/material/analyze
    POST /api/questions/generate
    POST /api/games/memory
    POST /api/games/riddle
    POST /api/evaluation/diagnostic
    POST /api/evaluation/analyze
    GET  /api/student/{student_id}/progress
    GET  /api/student/{student_id}/recommendations
"""

from __future__ import annotations

import json
import os
import re
from collections import defaultdict
from pathlib import Path
from typing import Any, Optional

from dotenv import load_dotenv
from fastapi import FastAPI, File, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from openai import OpenAI
from pydantic import BaseModel, Field
from sqlalchemy import Boolean, Float, ForeignKey, Integer, String, Text, create_engine, select
from sqlalchemy.orm import DeclarativeBase, Mapped, Session, mapped_column, relationship, sessionmaker

# ------------------------------------------------------------
# 1. Configuración
# ------------------------------------------------------------

load_dotenv()

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "").strip()
DATABASE_URL = os.getenv(
    "DATABASE_URL",
    "sqlite:///./edu_ai.db"
).strip()

# Modelo económico para generación de alto volumen.
# Se puede cambiar desde .env:
# OPENAI_MODEL=gpt-5.6-luna
OPENAI_MODEL = os.getenv("OPENAI_MODEL", "gpt-5.6-luna")

client: Optional[OpenAI] = OpenAI(api_key=OPENAI_API_KEY) if OPENAI_API_KEY else None

connect_args = {"check_same_thread": False} if DATABASE_URL.startswith("sqlite") else {}
engine = create_engine(DATABASE_URL, connect_args=connect_args)
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)

# ------------------------------------------------------------
# 2. Base de datos SQL
# ------------------------------------------------------------

class Base(DeclarativeBase):
    pass


class User(Base):
    __tablename__ = "users"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(120))
    email: Mapped[str] = mapped_column(String(255), unique=True, index=True)
    role: Mapped[str] = mapped_column(String(30), default="student")


class Material(Base):
    __tablename__ = "materials"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(255))
    material_type: Mapped[str] = mapped_column(String(30))
    extracted_text: Mapped[str] = mapped_column(Text)
    source_url: Mapped[Optional[str]] = mapped_column(String(1000), nullable=True)


class Topic(Base):
    __tablename__ = "topics"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    material_id: Mapped[int] = mapped_column(ForeignKey("materials.id"))
    name: Mapped[str] = mapped_column(String(255))
    description: Mapped[str] = mapped_column(Text, default="")
    keywords_json: Mapped[str] = mapped_column(Text, default="[]")


class Question(Base):
    __tablename__ = "questions"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    topic_id: Mapped[int] = mapped_column(ForeignKey("topics.id"))
    question: Mapped[str] = mapped_column(Text)
    correct_answer: Mapped[str] = mapped_column(Text)
    options_json: Mapped[str] = mapped_column(Text, default="[]")
    question_type: Mapped[str] = mapped_column(String(40), default="multiple_choice")
    difficulty: Mapped[int] = mapped_column(Integer, default=2)


class StudentAnswer(Base):
    __tablename__ = "student_answers"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    student_id: Mapped[int] = mapped_column(Integer, index=True)
    question_id: Mapped[int] = mapped_column(ForeignKey("questions.id"))
    topic_id: Mapped[int] = mapped_column(ForeignKey("topics.id"))
    answer: Mapped[str] = mapped_column(Text)
    correct: Mapped[bool] = mapped_column(Boolean, default=False)
    time_seconds: Mapped[Optional[float]] = mapped_column(Float, nullable=True)


class StudentProgress(Base):
    __tablename__ = "student_progress"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    student_id: Mapped[int] = mapped_column(Integer, index=True)
    topic_id: Mapped[int] = mapped_column(ForeignKey("topics.id"))
    attempts: Mapped[int] = mapped_column(Integer, default=0)
    correct_answers: Mapped[int] = mapped_column(Integer, default=0)
    wrong_answers: Mapped[int] = mapped_column(Integer, default=0)
    mastery_score: Mapped[float] = mapped_column(Float, default=0.0)


Base.metadata.create_all(bind=engine)

# ------------------------------------------------------------
# 3. FastAPI
# ------------------------------------------------------------

app = FastAPI(
    title="Edu-AI API",
    version="1.0.0",
    description="Motor de aprendizaje adaptativo para plataformas educativas."
)

# Para desarrollo local con React.
# En producción conviene restringir esto al dominio real.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

UPLOAD_DIR = Path("uploads")
UPLOAD_DIR.mkdir(exist_ok=True)

# ------------------------------------------------------------
# 4. Modelos de entrada
# ------------------------------------------------------------

class TextAnalysisRequest(BaseModel):
    title: str
    text: str = Field(min_length=20)
    student_level: str = "secundaria"


class GenerateQuestionsRequest(BaseModel):
    topic: str
    context: str = ""
    number_of_questions: int = Field(default=10, ge=1, le=50)
    difficulty: str = "medium"
    question_types: list[str] = Field(
        default_factory=lambda: ["multiple_choice", "true_false"]
    )


class StudentAnswerInput(BaseModel):
    question_id: int
    answer: str
    time_seconds: Optional[float] = None


class AnalyzeEvaluationRequest(BaseModel):
    student_id: int
    answers: list[StudentAnswerInput]


class StudentRequest(BaseModel):
    student_id: int


# ------------------------------------------------------------
# 5. Utilidades de IA
# ------------------------------------------------------------

SYSTEM_PROMPT = """
Eres Edu-AI, un motor especializado en aprendizaje adaptativo.

REGLAS IMPORTANTES:
1. Basa tus respuestas principalmente en el material proporcionado.
2. No inventes datos que no estén respaldados por el contenido.
3. Usa lenguaje claro para estudiantes.
4. Devuelve JSON válido cuando se solicite JSON.
5. Distingue entre tema, subtema y concepto.
6. Las preguntas deben evaluar comprensión real y no solamente reconocimiento.
7. Las respuestas correctas deben ser inequívocas.
"""

def require_ai() -> OpenAI:
    if client is None:
        raise HTTPException(
            status_code=500,
            detail=(
                "OPENAI_API_KEY no está configurada. "
                "Crea un archivo .env con OPENAI_API_KEY=..."
            ),
        )
    return client


def ai_json(system_prompt: str, user_prompt: str) -> dict[str, Any]:
    """
    Llama al modelo y solicita JSON estructurado.
    """
    ai = require_ai()

    response = ai.responses.create(
        model=OPENAI_MODEL,
        instructions=system_prompt,
        input=user_prompt,
    )

    raw = getattr(response, "output_text", "") or ""
    raw = raw.strip()

    # Limpieza por si el modelo devuelve ```json ... ```
    raw = re.sub(r"^```(?:json)?\s*", "", raw)
    raw = re.sub(r"\s*```$", "", raw)

    try:
        return json.loads(raw)
    except json.JSONDecodeError as exc:
        raise HTTPException(
            status_code=502,
            detail=f"La IA no devolvió JSON válido: {raw[:1000]}"
        ) from exc


# ------------------------------------------------------------
# 6. Extracción de contenido
# ------------------------------------------------------------

def extract_pdf(file_path: Path) -> str:
    try:
        from pypdf import PdfReader
    except ImportError as exc:
        raise HTTPException(
            status_code=500,
            detail="Instala pypdf con: pip install pypdf"
        ) from exc

    reader = PdfReader(str(file_path))
    pages = []
    for page in reader.pages:
        pages.append(page.extract_text() or "")
    return "\n\n".join(pages).strip()


def extract_pptx(file_path: Path) -> str:
    try:
        from pptx import Presentation
    except ImportError as exc:
        raise HTTPException(
            status_code=500,
            detail="Instala python-pptx con: pip install python-pptx"
        ) from exc

    prs = Presentation(str(file_path))
    slides = []

    for index, slide in enumerate(prs.slides, start=1):
        parts = [f"DIAPOSITIVA {index}"]
        for shape in slide.shapes:
            if hasattr(shape, "text") and shape.text:
                parts.append(shape.text)
        slides.append("\n".join(parts))

    return "\n\n".join(slides).strip()


def extract_youtube(url: str) -> str:
    """
    Intenta recuperar una transcripción disponible.
    No descarga el video.
    """
    try:
        from youtube_transcript_api import YouTubeTranscriptApi
    except ImportError as exc:
        raise HTTPException(
            status_code=500,
            detail=(
                "Instala youtube-transcript-api con: "
                "pip install youtube-transcript-api"
            )
        ) from exc

    match = re.search(r"(?:v=|youtu\.be/|shorts/)([A-Za-z0-9_-]{11})", url)
    if not match:
        raise HTTPException(status_code=400, detail="URL de YouTube no válida.")

    video_id = match.group(1)

    try:
        transcript = YouTubeTranscriptApi.get_transcript(
            video_id,
            languages=["es", "en"]
        )
    except Exception as exc:
        raise HTTPException(
            status_code=400,
            detail=(
                "No se pudo obtener una transcripción para ese video. "
                "Comprueba que el video tenga subtítulos/transcripción disponibles."
            )
        ) from exc

    return "\n".join(item["text"] for item in transcript).strip()


# ------------------------------------------------------------
# 7. Analizar contenido
# ------------------------------------------------------------

@app.post("/api/material/analyze")
async def analyze_material(
    file: Optional[UploadFile] = File(default=None),
):
    """
    Sube PDF/PPTX/TXT.
    El archivo se analiza y devuelve un mapa de conocimiento.
    """
    if file is None:
        raise HTTPException(status_code=400, detail="Debes enviar un archivo.")

    filename = file.filename or "material"
    extension = Path(filename).suffix.lower()

    file_path = UPLOAD_DIR / filename
    content = await file.read()
    file_path.write_bytes(content)

    if extension == ".pdf":
        extracted_text = extract_pdf(file_path)
        material_type = "pdf"
    elif extension == ".pptx":
        extracted_text = extract_pptx(file_path)
        material_type = "pptx"
    elif extension in {".txt", ".md"}:
        extracted_text = content.decode("utf-8", errors="ignore").strip()
        material_type = "text"
    else:
        raise HTTPException(
            status_code=400,
            detail="Formato no compatible. Usa PDF, PPTX, TXT o MD."
        )

    if not extracted_text:
        raise HTTPException(
            status_code=400,
            detail="No se pudo extraer texto del archivo."
        )

    prompt = f"""
Analiza el siguiente material educativo y crea un mapa de conocimiento.

Devuelve exactamente este esquema:

{{
  "title": "...",
  "summary": "...",
  "topics": [
    {{
      "name": "...",
      "description": "...",
      "subtopics": ["..."],
      "concepts": [
        {{
          "name": "...",
          "definition": "...",
          "keywords": ["..."]
        }}
      ]
    }}
  ]
}}

Material:
{extracted_text[:120000]}
"""

    analysis = ai_json(SYSTEM_PROMPT, prompt)

    with SessionLocal() as db:
        material = Material(
            name=filename,
            material_type=material_type,
            extracted_text=extracted_text,
        )
        db.add(material)
        db.commit()
        db.refresh(material)

        saved_topics = []

        for item in analysis.get("topics", []):
            topic = Topic(
                material_id=material.id,
                name=item.get("name", "Tema sin nombre"),
                description=item.get("description", ""),
                keywords_json=json.dumps(
                    [
                        keyword
                        for concept in item.get("concepts", [])
                        for keyword in concept.get("keywords", [])
                    ],
                    ensure_ascii=False
                ),
            )
            db.add(topic)
            db.commit()
            db.refresh(topic)

            saved_topics.append({
                "id": topic.id,
                "name": topic.name,
                "description": topic.description,
                "subtopics": item.get("subtopics", []),
                "concepts": item.get("concepts", []),
            })

    return {
        "success": True,
        "material_id": material.id,
        "material": filename,
        "analysis": {
            **analysis,
            "topics": saved_topics
        }
    }


# ------------------------------------------------------------
# 8. Analizar texto directo
# ------------------------------------------------------------

@app.post("/api/material/analyze-text")
def analyze_text(request: TextAnalysisRequest):
    prompt = f"""
Analiza el siguiente contenido de nivel {request.student_level}.

Devuelve:
{{
  "title": "{request.title}",
  "summary": "...",
  "topics": [
    {{
      "name": "...",
      "description": "...",
      "subtopics": ["..."],
      "concepts": [
        {{
          "name": "...",
          "definition": "...",
          "keywords": ["..."]
        }}
      ]
    }}
  ]
}}

CONTENIDO:
{request.text[:120000]}
"""

    analysis = ai_json(SYSTEM_PROMPT, prompt)

    with SessionLocal() as db:
        material = Material(
            name=request.title,
            material_type="text",
            extracted_text=request.text,
        )
        db.add(material)
        db.commit()
        db.refresh(material)

        for item in analysis.get("topics", []):
            topic = Topic(
                material_id=material.id,
                name=item.get("name", "Tema"),
                description=item.get("description", ""),
                keywords_json=json.dumps(
                    [
                        keyword
                        for concept in item.get("concepts", [])
                        for keyword in concept.get("keywords", [])
                    ],
                    ensure_ascii=False
                ),
            )
            db.add(topic)

        db.commit()
        material_id = material.id

    return {
        "success": True,
        "material_id": material_id,
        "analysis": analysis
    }


# ------------------------------------------------------------
# 9. YouTube
# ------------------------------------------------------------

class YouTubeRequest(BaseModel):
    url: str
    title: str = "Video de YouTube"


@app.post("/api/material/analyze-youtube")
def analyze_youtube(request: YouTubeRequest):
    text = extract_youtube(request.url)

    analysis = ai_json(
        SYSTEM_PROMPT,
        f"""
Analiza esta transcripción educativa de YouTube.

Devuelve:
{{
  "title": "{request.title}",
  "summary": "...",
  "topics": [
    {{
      "name": "...",
      "description": "...",
      "subtopics": ["..."],
      "concepts": [
        {{
          "name": "...",
          "definition": "...",
          "keywords": ["..."]
        }}
      ]
    }}
  ]
}}

TRANSCRIPCIÓN:
{text[:120000]}
"""
    )

    with SessionLocal() as db:
        material = Material(
            name=request.title,
            material_type="youtube",
            extracted_text=text,
            source_url=request.url,
        )
        db.add(material)
        db.commit()
        db.refresh(material)

    return {
        "success": True,
        "material_id": material.id,
        "analysis": analysis
    }


# ------------------------------------------------------------
# 10. Generación de preguntas
# ------------------------------------------------------------

@app.post("/api/questions/generate")
def generate_questions(request: GenerateQuestionsRequest):
    prompt = f"""
Genera {request.number_of_questions} preguntas educativas sobre:

TEMA:
{request.topic}

CONTEXTO:
{request.context[:80000]}

DIFICULTAD:
{request.difficulty}

TIPOS PERMITIDOS:
{request.question_types}

Devuelve exactamente:

{{
  "questions": [
    {{
      "question": "...",
      "type": "multiple_choice|true_false|short_answer",
      "options": ["...", "...", "...", "..."],
      "correct_answer": "...",
      "explanation": "...",
      "difficulty": 1,
      "topic": "{request.topic}"
    }}
  ]
}}

Para multiple_choice usa 4 opciones.
Para true_false usa ["Verdadero", "Falso"].
Para short_answer usa options=[].
No repitas preguntas.
"""

    result = ai_json(SYSTEM_PROMPT, prompt)

    # El endpoint puede funcionar incluso sin crear una FK de topic.
    return {
        "success": True,
        **result
    }


# ------------------------------------------------------------
# 11. Juegos
# ------------------------------------------------------------

@app.post("/api/games/memory")
def generate_memory_game(request: GenerateQuestionsRequest):
    prompt = f"""
Crea un juego de memoria educativo sobre "{request.topic}".

CONTEXTO:
{request.context[:80000]}

Devuelve exactamente:
{{
  "game_type": "memory",
  "title": "...",
  "instructions": "...",
  "pairs": [
    {{
      "id": 1,
      "front": "...",
      "back": "..."
    }}
  ]
}}

Crea entre 6 y 12 pares.
Cada pareja debe comprobar un concepto real del material.
"""

    result = ai_json(SYSTEM_PROMPT, prompt)
    return {"success": True, **result}


@app.post("/api/games/riddle")
def generate_riddle_game(request: GenerateQuestionsRequest):
    prompt = f"""
Crea un juego de adivinanzas educativas sobre "{request.topic}".

CONTEXTO:
{request.context[:80000]}

Devuelve exactamente:
{{
  "game_type": "riddle",
  "title": "...",
  "instructions": "...",
  "riddles": [
    {{
      "id": 1,
      "answer": "...",
      "clues": [
        "...",
        "...",
        "..."
      ],
      "explanation": "..."
    }}
  ]
}}

Crea 5-10 adivinanzas.
Las pistas deben ir de general a específica.
"""

    result = ai_json(SYSTEM_PROMPT, prompt)
    return {"success": True, **result}


# ------------------------------------------------------------
# 12. Evaluación diagnóstica
# ------------------------------------------------------------

@app.post("/api/evaluation/diagnostic")
def diagnostic_evaluation(request: GenerateQuestionsRequest):
    prompt = f"""
Crea una evaluación diagnóstica de {request.number_of_questions} preguntas.

TEMA:
{request.topic}

CONTEXTO:
{request.context[:80000]}

Objetivo:
- medir conocimientos previos;
- cubrir distintos subtemas;
- identificar fortalezas y debilidades;
- mezclar dificultades fácil, media y difícil.

Devuelve:
{{
  "title": "Evaluación diagnóstica",
  "questions": [
    {{
      "question": "...",
      "type": "multiple_choice",
      "options": ["...", "...", "...", "..."],
      "correct_answer": "...",
      "explanation": "...",
      "difficulty": 1,
      "subtopic": "...",
      "concept": "..."
    }}
  ]
}}
"""

    result = ai_json(SYSTEM_PROMPT, prompt)
    return {"success": True, **result}


# ------------------------------------------------------------
# 13. Registrar y analizar desempeño
# ------------------------------------------------------------

def mastery_from_results(correct: int, attempts: int) -> float:
    if attempts <= 0:
        return 0.0

    accuracy = correct / attempts
    # Modelo sencillo inicial. Más adelante se puede sustituir
    # por un modelo de dominio más avanzado.
    score = round(accuracy * 100, 2)
    return max(0.0, min(100.0, score))


@app.post("/api/evaluation/analyze")
def analyze_evaluation(request: AnalyzeEvaluationRequest):
    with SessionLocal() as db:
        per_topic: dict[int, dict[str, int]] = defaultdict(
            lambda: {"correct": 0, "attempts": 0}
        )

        saved = []

        for answer in request.answers:
            question = db.get(Question, answer.question_id)
            if question is None:
                # Si la pregunta vino de un generado temporalmente
                # y todavía no se guardó en SQL, simplemente se ignora.
                continue

            normalized_user = answer.answer.strip().lower()
            normalized_correct = question.correct_answer.strip().lower()
            correct = normalized_user == normalized_correct

            db_answer = StudentAnswer(
                student_id=request.student_id,
                question_id=question.id,
                topic_id=question.topic_id,
                answer=answer.answer,
                correct=correct,
                time_seconds=answer.time_seconds,
            )
            db.add(db_answer)

            per_topic[question.topic_id]["attempts"] += 1
            if correct:
                per_topic[question.topic_id]["correct"] += 1

            saved.append({
                "question_id": question.id,
                "correct": correct,
            })

        db.commit()

        progress_output = []

        for topic_id, stats in per_topic.items():
            progress = db.scalar(
                select(StudentProgress).where(
                    StudentProgress.student_id == request.student_id,
                    StudentProgress.topic_id == topic_id
                )
            )

            if progress is None:
                progress = StudentProgress(
                    student_id=request.student_id,
                    topic_id=topic_id
                )
                db.add(progress)

            progress.attempts += stats["attempts"]
            progress.correct_answers += stats["correct"]
            progress.wrong_answers += stats["attempts"] - stats["correct"]
            progress.mastery_score = mastery_from_results(
                progress.correct_answers,
                progress.attempts
            )

            topic = db.get(Topic, topic_id)

            progress_output.append({
                "topic_id": topic_id,
                "topic": topic.name if topic else f"Tema {topic_id}",
                "mastery_score": progress.mastery_score,
                "attempts": progress.attempts,
                "correct": progress.correct_answers,
                "wrong": progress.wrong_answers,
            })

        db.commit()

    weaknesses = [
        item for item in progress_output
        if item["mastery_score"] < 60
    ]

    strengths = [
        item for item in progress_output
        if item["mastery_score"] >= 80
    ]

    return {
        "success": True,
        "student_id": request.student_id,
        "answers": saved,
        "analysis": {
            "strengths": strengths,
            "needs_reinforcement": weaknesses,
            "recommendation": (
                "Practicar primero los temas con menor dominio."
                if weaknesses
                else "Buen dominio general. Puedes avanzar a actividades de mayor dificultad."
            )
        }
    }


# ------------------------------------------------------------
# 14. Progreso y recomendaciones
# ------------------------------------------------------------

@app.get("/api/student/{student_id}/progress")
def get_progress(student_id: int):
    with SessionLocal() as db:
        rows = db.scalars(
            select(StudentProgress).where(
                StudentProgress.student_id == student_id
            )
        ).all()

        data = []
        for row in rows:
            topic = db.get(Topic, row.topic_id)
            data.append({
                "topic_id": row.topic_id,
                "topic": topic.name if topic else f"Tema {row.topic_id}",
                "mastery_score": row.mastery_score,
                "attempts": row.attempts,
                "correct": row.correct_answers,
                "wrong": row.wrong_answers,
            })

    return {
        "success": True,
        "student_id": student_id,
        "progress": sorted(
            data,
            key=lambda x: x["mastery_score"]
        )
    }


@app.get("/api/student/{student_id}/recommendations")
def get_recommendations(student_id: int):
    with SessionLocal() as db:
        rows = db.scalars(
            select(StudentProgress).where(
                StudentProgress.student_id == student_id
            )
        ).all()

        weak_topics = []
        strong_topics = []

        for row in rows:
            topic = db.get(Topic, row.topic_id)
            item = {
                "topic_id": row.topic_id,
                "topic": topic.name if topic else f"Tema {row.topic_id}",
                "mastery_score": row.mastery_score,
            }

            if row.mastery_score < 60:
                weak_topics.append(item)
            elif row.mastery_score >= 80:
                strong_topics.append(item)

    weak_topics.sort(key=lambda x: x["mastery_score"])

    recommendations = []

    for item in weak_topics[:5]:
        if item["mastery_score"] < 40:
            activity = "memoria + explicación guiada + evaluación corta"
        else:
            activity = "adivinanzas + tarjetas de memoria + quiz"

        recommendations.append({
            "topic": item["topic"],
            "mastery_score": item["mastery_score"],
            "recommended_activity": activity,
            "goal": "subir el dominio al menos a 70%"
        })

    return {
        "success": True,
        "student_id": student_id,
        "recommendations": recommendations,
        "strengths": strong_topics,
    }


# ------------------------------------------------------------
# 15. Salud de API
# ------------------------------------------------------------

@app.get("/api/health")
def health():
    return {
        "status": "ok",
        "service": "Edu-AI",
        "ai_configured": bool(OPENAI_API_KEY),
        "database": DATABASE_URL.split("://")[0],
        "model": OPENAI_MODEL,
    }


# ------------------------------------------------------------
# NOTA:
# Para producción:
# - usar autenticación JWT;
# - restringir CORS;
# - validar tamaño y tipo de archivos;
# - guardar archivos en almacenamiento seguro;
# - usar PostgreSQL;
# - añadir control de permisos profesor/estudiante;
# - registrar auditoría;
# - mejorar el cálculo de dominio con un modelo psicométrico;
# - validar contenido generado por IA antes de publicarlo.
# ------------------------------------------------------------
